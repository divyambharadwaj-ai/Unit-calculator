DHAROHAR QUOTE CALCULATOR — VS CODE QUICK START

Files:
- index.html: Complete web app. HTML provides structure, CSS provides styling, and JavaScript handles calculations and interactions.

Run:
1. Extract this folder if downloaded as a ZIP.
2. Open the folder in Visual Studio Code.
3. Open index.html in Chrome/Edge, or install the Live Server extension in VS Code.
4. Right-click index.html and choose Open with Live Server.

No Node.js or backend is required for the current client-side version.

Notes:
- Google Fonts require an internet connection.
- Calculator rate settings and agent details are stored in the browser's localStorage, not a shared database.
- Inventory is currently defined in JavaScript and is not connected to a live database.
